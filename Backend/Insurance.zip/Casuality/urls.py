from django.urls import path


urlpatterns=[
    # path('Emergency_Registration_Details', Emergency_Registration_Details, name='Emergency_Registration_Details'),
]



