from django.apps import AppConfig


class LeninmanagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LeninManagement'
